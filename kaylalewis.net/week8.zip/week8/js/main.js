//Parallax

$('.top').parallax({

	imageSrc: 'img/nebula.jpg'

});

$('#print').parallax({
	imageSrc: 'img/horsehead.jpg',
	speed:0.5
});

$('#colonize').parallax({

	imageSrc: 'img/mars.jpg',

});

//Smoothscroll


function events() {
$('#events').ScrollTo({
    duration: 1000,
    easing: 'linear'
});

}

function colonize() {
$('#colonize').ScrollTo({
    duration: 1000,
    easing: 'linear'
});

}

function lsst() {
$('#lsst').ScrollTo({
    duration: 1000,
    easing: 'linear'
});

}

function print() {
$('#print').ScrollTo({
    duration: 1000,
    easing: 'linear'
});

}

